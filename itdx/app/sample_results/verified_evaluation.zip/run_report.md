MYCOSOFT / ITDX26 LOCAL EVALUATION REPORT

run-a3306885224e4bdc

Created: 2026-09-08T16:26:54.637332+00:00

Data mode: SYNTHETIC_TEST

Dataset: Coastal Sentinel • reproducible synthetic replay

Scenario: clean

Seed: 11



EVIDENCE BOUNDARY

Measured local CPU execution. Synthetic data does not establish field performance.

The local readout is not a full trained SSM/Mamba or relational GNN.

The local MYCA option loop is deterministic. No actuator commands are issued.

Final Army injects and acceptance rubric have not been supplied.



RUN CONFIGURATION

Native NLM encoder + 25 fitted readout parameters

Model SHA-256: 364c1c79d9bf4f94e622b88b38e59af14825c673ba3c02ffd53acf0e571eab93

Training origin: synthetic_training_captures

Training records: 320; validation: 320

Inputs: 960; held-out task 12 records: 320



TASK METRICS

Task 12 / native_encoder / MEASURED

  n=320; precision=0.87500; recall=0.06306; f1=0.11765; average_precision=0.38018; auroc=0.52914; brier=0.33600; ece=0.33937

Task 12 / robust_baseline / MEASURED

  n=320; precision=0.95690; recall=1.00000; f1=0.97797; average_precision=1.00000; auroc=1.00000; brier=0.02178; ece=0.08198

Task 12 / temporal_readout / MEASURED

  n=320; precision=1.00000; recall=1.00000; f1=1.00000; average_precision=1.00000; auroc=1.00000; brier=0.00125; ece=0.02034

Task 13 / spatial_baseline / MEASURED

  n=480; precision=0.33125; recall=1.00000; f1=0.49765; average_precision=0.33523; auroc=0.51176; brier=0.55498; ece=0.57708

Task 13 / temporal_corroboration / MEASURED

  n=480; precision=1.00000; recall=1.00000; f1=1.00000; average_precision=1.00000; auroc=1.00000; brier=0.00446; ece=0.04629

Task Interaction / fused / MEASURED

  n=320; precision=1.00000; recall=1.00000; f1=1.00000; average_precision=1.00000; auroc=1.00000; brier=0.00213; ece=0.01942

Task Interaction / graph_context / MEASURED

  n=320; precision=0.95690; recall=1.00000; f1=0.97797; average_precision=0.92966; auroc=0.98457; brier=0.02051; ece=0.04569

Task Interaction / sequence / MEASURED

  n=320; precision=1.00000; recall=1.00000; f1=1.00000; average_precision=1.00000; auroc=1.00000; brier=0.00125; ece=0.02034

Task Interaction / shuffled_control / MEASURED

  n=320; precision=1.00000; recall=0.38739; f1=0.55844; average_precision=1.00000; auroc=1.00000; brier=0.07338; ece=0.13836



COVERAGE AND MISSED DETECTIONS

{"abstained_positive_records": 0, "coverage": 1.0, "definition": "All labeled held-out records; abstained positive observations count as missed detections. Classifier F1 above uses only eligible predictions.", "false_alerts": 0, "false_positive_rate": 0.0, "labelled_records": 320, "missed_positive_records": 0, "recall_including_abstentions": 1.0, "status": "MEASURED", "test_records": 320}



SCENARIO IMPACT

MEASURED

Scenario impact against the same seed, selected dataset and constraints. Injected labels/populations may differ; deltas are sensitivity measurements, not causal improvement or Army pass/fail thresholds.

Delta from unchanged capture: {"coverage": 0.0, "events": 0, "excluded_advisory_evidence": 0, "f1": 0.0, "false_alerts": 0, "gated_options": 0, "graph_f1": 0.0, "labelled_records": 0, "mapped_records": 0, "median_detection_seconds": 0.0, "missed_events": 0, "missed_positive_records": 0, "missing_geometry": 0, "passing_options": 0, "precision": 0.0, "recall": 0.0, "seconds": 0.0, "sources": 0, "stale_records": 0, "supporting_pairs": 0, "test_records": 0, "vetoed_options": 0}



TASK 8 / OPTIONS AND GOVERNANCE

Mode: DETERMINISTIC_SEVEN_ROLE_REVIEW

Policy digest: e85133bcee02fd57e120c6dc5fa20ea6459537748fa02de463699f4f096878ab

Evidence age and exclusions: {"basis": "Recorded ingestion cutoff; only fresh observed-time evidence with resolved identity can ground options.", "candidate_records": 111, "cutoff_epoch": 1789031591.0, "eligible_records": 16, "max_age_seconds": 300.0, "stale_or_unresolved_excluded": 61}

coa-1 / Continue observation / PASS

Native AVANI: allow

Failed checks: none

Evidence: test-063-hyphae-1, test-064-mushroom-1, test-061-mushroom-1, test-062-hyphae-1, test-063-agaric-1, test-062-psathyrella-1, test-061-agaric-1, test-062-mushroom-1

Envelope: {"authority": "Analyst review only", "duration_minutes": 15, "identity": "observe", "magnitude": "One advisory option", "preconditions": ["goal_present", "fresh_evidence", "within_cost", "within_duration", "resource_available", "action_allowed", "independent_sources", "independent_modalities", "uncertainty", "distinct"], "rollback": "Withdraw recommendation; preserve the evidence record", "scope": "Synthetic/recorded environmental monitoring only", "stop_conditions": ["Evidence is invalidated", "Analyst stops review"]}

coa-2 / Request independent corroboration / PASS

Native AVANI: monitor

Failed checks: none

Evidence: test-063-hyphae-1, test-064-mushroom-1, test-061-mushroom-1, test-062-hyphae-1, test-063-agaric-1, test-062-psathyrella-1, test-061-agaric-1, test-062-mushroom-1

Envelope: {"authority": "Analyst review only", "duration_minutes": 20, "identity": "request_sample", "magnitude": "One advisory option", "preconditions": ["goal_present", "fresh_evidence", "within_cost", "within_duration", "resource_available", "action_allowed", "independent_sources", "independent_modalities", "uncertainty", "distinct"], "rollback": "Withdraw recommendation; preserve the evidence record", "scope": "Synthetic/recorded environmental monitoring only", "stop_conditions": ["Evidence is invalidated", "Analyst stops review"]}

coa-3 / Restore the evidence connection / PASS

Native AVANI: monitor

Failed checks: none

Evidence: test-063-hyphae-1, test-064-mushroom-1, test-061-mushroom-1, test-062-hyphae-1, test-063-agaric-1, test-062-psathyrella-1, test-061-agaric-1, test-062-mushroom-1

Envelope: {"authority": "Analyst review only", "duration_minutes": 30, "identity": "restore_link", "magnitude": "One advisory option", "preconditions": ["goal_present", "fresh_evidence", "within_cost", "within_duration", "resource_available", "action_allowed", "independent_sources", "independent_modalities", "uncertainty", "distinct"], "rollback": "Withdraw recommendation; preserve the evidence record", "scope": "Synthetic/recorded environmental monitoring only", "stop_conditions": ["Evidence is invalidated", "Analyst stops review"]}



TASK 14 / MAP

{"mapped_records": 320, "missing_geometry": 0, "stale_records": 0}

CRS: EPSG:4326; no online basemap required.

Age is relative to the replay cutoff, not the wall clock.



TIMING AND HARDWARE

{"budget_seconds": 420, "definition": "Input validation through analyst products and interaction; export/storage measured separately", "model_setup_seconds": 0.1329313900005218, "task12_seconds": 0.03336427099930006, "task13_seconds": 0.008158839998941403, "task14_seconds": 0.002003518000492477, "task8_seconds": 0.0005491290012287209, "total_seconds": 0.2692359379998379, "within_budget": true}

{"gpu": "Not used; CPU reference execution", "platform": "Linux-6.18.35-x86_64-with-glibc2.39", "process_lifetime_peak_rss_mb": 48.72265625, "processor": "x86_64", "python": "3.12.13"}



PROVENANCE

Observation Merkle root: 189698db0f18a99c92828eb3f258a9e8e92218a1e8ff17775f71be60d11ede9d

Frame root: cb1edc5ce4c74d1d2e7cea40b0d9c78ca3da43469ec8b13666895e888e863e1d

Parent root: (genesis)

Stable output digest: 9bf44a40d640dccfe854115a93558e1afb73c4a161fd442d38d1a5bdb5a51b89

Hash integrity does not establish measurement truth or external key ownership.



SME ADJUDICATION

No SME ratings recorded. Unsupported-assertion rate is not automatically measured.



LIMITATIONS

Final Army agenda, official inject pack and acceptance rubric require confirmation.

Synthetic metrics do not establish operational accuracy.

Full NLM SSM, relational GNN and multi-LLM MYCA services were not used in this local run.

Local SQLite evidence store is not a deployed production MINDEX/PostgreSQL instance.

Synthetic capture results are not field validation.

This readout is not a trained SSM/Mamba foundation model.

Missing native inputs are exposed; the upstream encoder itself substitutes zeros.

This local graph scorer is deterministic; no relational GNN checkpoint is loaded.

Node removal is a sensitivity test, not a causal intervention.

The local role loop does not simulate independent LLM agents.

A passing advisory gate never grants command authority.



EXPORT REPLAY

Verify integrity: python verify_bundle.py evaluation.zip

Exact product replay: python replay.py evaluation.zip (from the matching app release)

Use --trusted-key-sha256 with a separately recorded signing-key fingerprint.

All inputs, truth labels, model parameters and stable outputs are in the ZIP.