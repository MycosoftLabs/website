# Release validation — 2026-09-08

Application version: 1.0.0. Evidence: local Linux/Python 3.12.13 execution.

| Check | Result | Evidence file |
|---|---|---|
| Core algorithm, input, persistence, document and cryptography tests | 37 passed | sample_results/python_tests.txt |
| Real HTTP server and API checks | 38 passed | sample_results/http_acceptance.json |
| JavaScript views and action functions, using actual API response fixtures | 30 passed | sample_results/javascript_view_tests.json |
| Scenario sweep | 41 passed; 0 failed; 0 errors | sample_results/scenario_suite.json |
| Five seed trials | Completed | sample_results/five_seed_comparison.json |
| Exported artifact integrity and Ed25519 signature | Valid | sample_results/verification_result.json |
| Independently pinned signing fingerprint | Verified in HTTP checks | sample_results/SIGNER_FINGERPRINT.txt |
| Exact product replay | All five product groups match | sample_results/replay_result.json |
| PDF text, structure and visual pagination | Parsed and three pages inspected | sample_results/evaluation_report.pdf |
| Browser visual / click testing | Blocked by session URL policy; not claimed | Rehearse in your own local browser |
| Windows / macOS execution | Launchers supplied; not OS-tested | Start_Windows.bat / Start_Mac.command |
| Official ITDX acceptance / physical field gates | Not established | Official rubric and accepted field evidence not supplied |

## Measured example

Run `run-58e057d52f284ac4`: **SYNTHETIC_TEST**, seed 11, 960 observations, 320 held-out observations. Training origin: `synthetic_training_captures`.

- Local integrated product runtime: 0.2547 seconds. Model setup: 0.1298 seconds. The cached model path and repeated warm runs differ.
- HTTP application initialization: 0.0520 seconds. This is not a browser cold-map rendering measurement.
- Full scenario sweep: 9.374 seconds. PASS denotes the named software invariant, not Army acceptance or detection accuracy.
- Native encoder F1: 0.117647; recall: 0.063063.
- Robust baseline F1: 0.977974.
- Local temporal readout F1: 1.000000. The generated fixture is easy and is not independent field validation.
- Mean fused-minus-sequence F1 across five seeds: 0.000000; t interval [0.0, 0.0]. This result shows no F1 gain on the clean synthetic fixture.
- No SME scores are invented in the example export. Test-only reviewer entries exist only inside temporary unit-test databases.

## Checks with substantive failure behavior

Held-out label changes leave fitted parameters and inference scores unchanged. Group leakage, non-finite data, naive timestamps, conflicting IDs/origins, impossible constraints, unknown ontology, reversed edge leakage and invalid relation types are explicitly handled. Removing a source changes the graph and map support. HMAC modification, sequence equivocation, unaccepted model versions and future timestamps are quarantined in the software queue experiments. Candidate update norms are checked, not accepted by a preset result label.

The independent verifier rejects changed artifacts, rewritten signed manifests and incorrect pinned keys. Merkle proofs bind leaf index/directions and reject a changed record. The export contains no private signing key. A fresh source release must match the frozen code manifest before replay is allowed.

## Remaining rehearsal

On the presentation laptop, launch once before going offline, confirm optional signing availability, complete the seven walkthrough steps, inspect map selection/filters and document dialogs, import a small real measurement file, then export and independently verify a fresh bundle. Check screen scaling, download location, PDF readability and actual browser map startup timing. Confirm the final Army scenario, task priority, injects and rubric with the event owner. Full trained model services and physical demonstrations require their own qualification.


## Startup repair revision

The localhost address in the prior chat referred to an isolated execution workspace. It was not a reachable link for the separate in-app browser. The repaired package provides START_HERE launchers to create the server on the actual presentation computer.

Eleven additional launcher tests passed on Linux; see `sample_results/launcher_tests.txt`. Coverage includes incomplete extraction, required-file validation, missing-dependency failure, explicitly unsigned operation, occupied-port fallback, rejection of unrelated HTTP services, failed child-process startup, diagnostics, a real healthy server, compatibility with the old launcher name, and verification that browser dispatch is attempted only after the correct local server responds. The dispatch test uses a callback; it does not claim visual browser validation.

Windows bootstrap locates compatible Python or attempts installation using the Microsoft-documented WinGet package; Mac opens the official installer page if Python is absent. Missing signing dependencies are installed into an isolated environment. The launcher records startup errors, confirms the selected port, and opens a normal local browser only after readiness. Neither browser policy nor app host/origin protections were relaxed.

Algorithm source files and the existing evidence bundle remain unchanged. Exact replay still matches the supplied example. Windows/macOS OS-level installer execution and the user's actual laptop remain unverified. Run the repaired launcher on that computer, then inspect `local_data/startup.log` if it fails.
